# Custom a element

1. Upload both file to your assets folder in the Theme
2. Edit Test.ecom.html to custom your code
